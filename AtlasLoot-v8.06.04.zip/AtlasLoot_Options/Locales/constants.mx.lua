local AL = _G.AtlasLoot.GetLocales("esMX")

if not AL then return end

-- These localization strings are translated on WoWAce: https://www.wowace.com/projects/atlasloot-enhanced/localization
-- Options
AL["AtlasLoot Options"] = "Opciones AtlasLoot"

