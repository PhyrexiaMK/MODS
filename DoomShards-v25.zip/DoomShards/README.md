# Doom Shards

World of Warcraft: Legion addon which integrates Doom tracking into a Soul Shard display.

Go to http://wow.curseforge.com/addons/doom-shards/ for properly packaged versions.
