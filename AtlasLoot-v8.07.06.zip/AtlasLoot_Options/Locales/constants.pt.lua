local AL = _G.AtlasLoot.GetLocales("ptBR")

if not AL then return end

-- These localization strings are translated on WoWAce: https://www.wowace.com/projects/atlasloot-enhanced/localization
-- Options




