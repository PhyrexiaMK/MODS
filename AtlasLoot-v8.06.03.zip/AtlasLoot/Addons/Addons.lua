local AtlasLoot = _G.AtlasLoot
local Addons = {}
AtlasLoot.Addons = Addons
