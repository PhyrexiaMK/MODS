# Parrot 2

## [v2.0.10](https://github.com/nebularg/Parrot2/tree/v2.0.10) (2017-09-06)
[Full Changelog](https://github.com/nebularg/Parrot2/compare/v2.0.9...v2.0.10)

- Update TOC for 7.3  
- Revert "Force 7.2.0 as the game version for Curse uploads"  
